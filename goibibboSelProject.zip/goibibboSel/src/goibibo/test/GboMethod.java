package goibibo.test;


import javax.swing.JOptionPane;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class GboMethod {
	
	public  void input(WebDriver driver,By city) throws Exception
	{		
		WebElement tcity=driver.findElement(city);
		if(tcity.isDisplayed())
		{
			tcity.sendKeys(JOptionPane.showInputDialog("Enter Input city:"));
			Thread.sleep(1000);
		}
		
	}

	public void Click(WebDriver driver,By tdate) throws InterruptedException
	{
		WebElement date = driver.findElement(tdate);
		if(date.isDisplayed())
		{		
			date.click();
			driver.findElement(By.id("fare_"+JOptionPane.showInputDialog("Enter Input date eg(yyyymmdd):"))).click();
			Thread.sleep(1000);
		}
		
	}
	
	public void selectClass(WebDriver driver,By class1)
	{
		Select c=new Select(driver.findElement(class1)); 
		c.selectByIndex(1);
		
	}
}


/*driver.findElement(city).click();  for input method
		//String str=driver.findElement(city).getText();
		//driver.findElement(city).sendKeys(str);
		//System.out.println(str);
		 * 
		 */
		

/*DateFormat df=new SimpleDateFormat("dd");
Date d1=new Date();
String today=df.format(d1);
List<WebElement> dates=date.findElements(tdate);
for(WebElement d:dates)
{
	String temp=d.getText();
	if(temp.equals(today))
	{
		d.click();
		Thread.sleep(1000);
		break;
	
	}
	d.click();
}*/




