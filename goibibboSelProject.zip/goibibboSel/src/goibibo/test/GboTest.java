package goibibo.test;

import goibibo.page.goibiboPages;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.swing.JOptionPane;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class GboTest {
	public WebDriver driver;
	Document document;
	@BeforeClass
	public void initTestEle() throws Exception {
				
		System.setProperty("webdriver.chrome.driver", "D:\\adselJAR\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.goibibo.com/");
		System.out.println("Starting Test");
		File src = new File("./Configure/gbo.xml");
		FileInputStream fis = new FileInputStream(src);
		SAXReader sax=new SAXReader();
		document = sax.read(fis);
		
	}
  @Test
  public void testData() throws Exception {

	  //to read the property file create an obj of properties class
	 	GboMethod gmethod=new GboMethod();	
	 	
	 	gmethod.input(driver,By.id(document.selectSingleNode("//Details/fromcity").getText()));
		Thread.sleep(1000);
		gmethod.input(driver,By.id(document.selectSingleNode("//Details/tocity").getText()));
		Thread.sleep(1000);
		
		gmethod.Click(driver,By.xpath(document.selectSingleNode("//Details/departdate").getText()));
		Thread.sleep(1000);
		gmethod.Click(driver,By.xpath(document.selectSingleNode("//Details/returndate").getText()));
		Thread.sleep(1000);
		
		gmethod.selectClass(driver,By.xpath(document.selectSingleNode("//Details/class").getText()));
		Thread.sleep(3000);
		
		driver.close();
  }
}
