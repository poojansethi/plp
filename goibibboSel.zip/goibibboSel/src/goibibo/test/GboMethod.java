package goibibo.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class GboMethod {
	
	public  void input(WebDriver driver,By city) throws Exception
	{		
		System.out.println(city);
		driver.findElement(city).sendKeys(JOptionPane.showInputDialog("Enter Input :"));
		Thread.sleep(1000);
	}

	public void Click(WebDriver driver,By tdate) throws InterruptedException
	{
		WebElement date = driver.findElement(tdate);
		System.out.println(tdate);
		Thread.sleep(1000);

		//date.sendKeys(Keys.TAB);
		date.click();
		driver.findElement(By.id("fare_"+JOptionPane.showInputDialog("Enter Input :"))).click();
		
		
	}
	
	public void selectClass(WebDriver driver,By class1)
	{
		Select c=new Select(driver.findElement(class1)); 
		c.selectByIndex(1);
		
	}
}




/*DateFormat df=new SimpleDateFormat("dd");
Date d1=new Date();
String today=df.format(d1);
List<WebElement> dates=date.findElements(tdate);
for(WebElement d:dates)
{
	String temp=d.getText();
	if(temp.equals(today))
	{
		d.click();
		Thread.sleep(1000);
		break;
	
	}
	d.click();
}*/




